<?php
// File: generate-snap-token.php (Menggunakan $_POST)
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); 
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// --- PENGATURAN MIDTRANS ---
$midtrans_server_key = '[GANTI DENGAN SERVER KEY ANDA]'; 
$api_url = 'https://api.sandbox.midtrans.com/v1/transactions'; // Ganti ke https://api.midtrans.com/v1/transactions untuk PRODUKSI

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// --- 1. Ambil data dari $_POST ---
$order_data = $_POST;

if (!$order_data || !isset($order_data['price'], $order_data['name'], $order_data['order_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Data order tidak lengkap.', 'post_data_received' => $_POST]);
    exit;
}

// --- 2. Lanjutkan Proses Token Generation ---
$price = (int)$order_data['price'];
$name = $order_data['name'];
$order_id = $order_data['order_id'];

$params = [
    'transaction_details' => [
        'order_id' => $order_id,
        'gross_amount' => $price,
    ],
    'item_details' => [
        [
            'id' => 'PROD-' . substr(md5($name), 0, 5),
            'price' => $price,
            'quantity' => 1,
            'name' => $name,
        ]
    ],
];

// --- 3. Panggil API Midtrans (Curl) ---
$headers = [
    'Content-Type: application/json',
    'Accept: application/json',
    'Authorization: Basic ' . base64_encode($midtrans_server_key . ':') 
];

$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code == 201) {
    $midtrans_response = json_decode($response, true);
    echo json_encode(['token' => $midtrans_response['token']]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Gagal terhubung ke Midtrans. Code: ' . $http_code . '. Response: ' . $response]);
}
?>