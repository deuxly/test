<?php
// File: webhook.php
// ⚠️ Ini adalah endpoint yang HARUS didaftarkan di Dasbor Midtrans Anda

// --- 1. GANTI DENGAN KUNCI DAN LINK ANDA ---
$midtrans_server_key = '[Mid-server-fIlPFwXfEtRLmTBBRuMTGKcs]'; 
// Link GDrive/file yang akan dikirim (Link ini harus aman)
$download_link = "[https://deuxly.id]"; 
$your_shop_email = "[gilangitt@gmail.com]";

// --- 2. Ambil data Webhook ---
$json_data = file_get_contents('php://input');
$notification = json_decode($json_data, true);

if (!$notification) {
    http_response_code(400);
    die('Invalid JSON');
}

$order_id = $notification['order_id'];
$transaction_status = $notification['transaction_status'];
$gross_amount = $notification['gross_amount'];

// --- 3. Cek Status Pembayaran ---
if ($transaction_status == 'settlement' || $transaction_status == 'capture') {
    
    // ⚠️ SIMULASI MENGAMBIL EMAIL PEMBELI
    // Di produksi, Anda harus menyimpan email saat generate token dan mengambilnya di sini.
    // Karena ini simulasi, kita pakai email dummy. GANTI INI DENGAN LOGIKA DATABASE!
    $customer_email = "contoh-pembeli@gmail.com"; 

    // --- 4. Kirim Email Otomatis ---
    $subject = "🎉 File Ebook Anda Siap Diunduh! (Order #$order_id)";
    $message = "Halo,\n\nPembayaran Anda untuk produk ('Ebook') telah berhasil. Jumlah: Rp " . number_format($gross_amount) . ".\n\nBerikut link unduhan file Anda:\n\n$download_link\n\nTerima kasih,\n[Nama Toko Anda]";
    
    $headers = "From: noreply@[DOMAIN ANDA]" . "\r\n" .
               "Reply-To: $your_shop_email" . "\r\n" .
               'X-Mailer: PHP/' . phpversion();
               
    // HANYA MENGGUNAKAN FUNGSI MAIL() JIKA ANDA TIDAK MEMILIKI ESP (SendGrid/Mailgun)
    // mail($customer_email, $subject, $message, $headers); 

    // --- 5. Logging dan Respons ---
    http_response_code(200); // Harus mengirim 200 OK ke Midtrans
    file_put_contents('webhook_log.txt', date('Y-m-d H:i:s') . " - SUCCESS Order $order_id. Amount: $gross_amount. \n", FILE_APPEND);
    
} else {
    // Tangani status lain
    http_response_code(200); 
    file_put_contents('webhook_log.txt', date('Y-m-d H:i:s') . " - $transaction_status Order $order_id \n", FILE_APPEND);
}
?>