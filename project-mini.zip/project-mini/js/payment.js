document.addEventListener('DOMContentLoaded', () => {
    const API_ENDPOINT = 'api/generate-snap-token.php'; 
    const buyButtons = document.querySelectorAll('[id^="buy-button-"]');
    
    const handlePayment = async (price, name) => {
        const orderId = 'ORDER-' + Date.now() + Math.floor(Math.random() * 9999);

        // --- Perbaikan: Menggunakan URLSearchParams untuk FormData ---
        const postData = new URLSearchParams();
        postData.append('price', price);
        postData.append('name', name);
        postData.append('order_id', orderId);

        try {
            const response = await fetch(API_ENDPOINT, {
                method: 'POST',
                // Hapus header Content-Type karena browser akan menanganinya
                body: postData, 
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Server PHP Error:', response.status, errorText);
                alert(`Gagal terhubung ke server PHP (${response.status}).`);
                return;
            }

            const data = await response.json();

            if (data.token) {
                snap.pay(data.token, {
                    onSuccess: function(result) {
                        window.location.href = 'success.html?order=' + result.order_id; 
                    },
                    onPending: function(result) {
                        alert("Pembayaran Tertunda. Segera selesaikan pembayaran.");
                    },
                    onError: function(result) {
                        alert("Pembayaran Gagal.");
                    }
                });
            } else {
                console.error('Error dari Server PHP:', data.error);
                alert(`Gagal mendapatkan token: ${data.error}.`);
            }

        } catch (error) {
            console.error('Error saat inisiasi pembayaran (Network/CORS):', error);
            alert('Terjadi kesalahan koneksi.');
        }
    };

    buyButtons.forEach(button => {
        button.addEventListener('click', () => {
            const price = parseInt(button.dataset.price);
            const name = button.dataset.name;
            if (isNaN(price) || !name) return;
            handlePayment(price, name);
        });
    });
});